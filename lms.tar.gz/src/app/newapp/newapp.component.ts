import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newapp',
  templateUrl: './newapp.component.html',
  styleUrls: ['./newapp.component.scss']
})
export class NewappComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
