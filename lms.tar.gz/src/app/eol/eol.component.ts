import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eol',
  templateUrl: './eol.component.html',
  styleUrls: ['./eol.component.scss']
})
export class EolComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
